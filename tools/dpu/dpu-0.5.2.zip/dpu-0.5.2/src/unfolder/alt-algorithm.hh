
#ifndef _C15U_ALTALGORITHM_HH_
#define _C15U_ALTALGORITHM_HH_

namespace dpu
{

typedef enum { SDPOR, ONLYLAST, KPARTIAL, OPTIMAL } Altalgo;

};

#endif
