
Based on Google Tests 1.8.0, downloaded from 
https://github.com/google/googletest/releases,
and stripped to the current state.
