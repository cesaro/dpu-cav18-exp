#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

int main ()
{
   abort ();
   return 0;
}

