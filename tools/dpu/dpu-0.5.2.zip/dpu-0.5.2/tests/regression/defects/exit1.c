#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>

int main (int argc, char ** argv)
{
   (void) argc;
   (void) argv;

   exit (17);

   return 0;
}

