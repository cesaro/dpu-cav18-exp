Add here the svcomp16 bech, once we make them work with DPU.
