
#include <sys/types.h>

int _rt_close (int fd);
