
int main ()
{
   int x;
   int y;
   x = 123;
   y = x;
   return x;
}
