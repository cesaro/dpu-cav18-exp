
#ifndef _STEROID_CONFIG_H_
#define _STEROID_CONFIG_H_

/* see src/verbosity.h for more info */
//#define CONFIG_MAX_VERB_LEVEL 3
#define CONFIG_MAX_VERB_LEVEL 1

/* test and debug */
//#define CONFIG_DEBUG
#undef CONFIG_DEBUG

#endif
